//-----------------------------------------------------------------------------
// DBAdapter.java
//
// 2012-2013 GubboIT
//
// 2013-03-21 Faster insert of solar data into db (from 20s to 2s)
// 2012-02-22 First version
//-----------------------------------------------------------------------------
package se.gubboit.solarone;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBAdapter {
	// Fields in table locations
	// Table locations
	public static final String KEY_ROWID = "_id"; // Also used as part of table name: L+"_id" (daily values)
	public static final String KEY_PLACE = "place";
	public static final String KEY_TZ = "tz";
	public static final String KEY_LAT = "lat";
	public static final String KEY_LONG = "long";
	public static final String KEY_YEAR = "year";
	public static final String TAG = "DBAdapter";
	// Year table L1...
	public static final String KEY_MONTH = "month";
	public static final String KEY_DAY = "day";
	public static final String KEY_HUP = "hup";
	public static final String KEY_MUP = "mup";
	public static final String KEY_HDOWN = "hdown";
	public static final String KEY_MDOWN = "mdown";
	public static final String KEY_HLEN = "hlen";
	public static final String KEY_MLEN = "mlen";	
	public static final String KEY_ELEV = "elev"; 		// Elevation in degrees at solar noon
	public static final String KEY_AZIUP = "aziup"; 	// Azimuth in degrees at sunrise
	public static final String KEY_AZIDOWN = "azidown"; 	// Azimuth in degrees at sunset
	
	public static final String DATABASE_NAME = "soldb";
	public static final String DATABASE_TABLE = "locations";	
	public static final int DATABASE_VERSION = 1;
	
	public static final String DATABASE_CREATE_LOC = 
			"create table locations (_id integer primary key autoincrement, " +
			"place text not null, tz text not null, lat real not null, long real not null, year integer not null);";
	
	private final Context context;
	private DatabaseHelper DBHelper;
	private SQLiteDatabase db;
	
	public DBAdapter(Context ctx) {  // Constructor
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);
	}
	//------------------------------------------------------------------------------------------
	// DatabaseHelper: Database creation and version management
	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		private final Context myContext;
		
		DatabaseHelper(Context context) // Constructor
		{
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			myContext = context;
		}
		
		@Override
		public void onCreate(SQLiteDatabase db) // Called when the db is created for the first time
		{ 
			try {
				db.execSQL(DATABASE_CREATE_LOC);
			} catch (SQLException e) {
				e.printStackTrace();		
			}
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
		{
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to " +
					 newVersion + ". Old data is destroyed.");
			// Drop all year tables
			Cursor c = db.query(DATABASE_TABLE, new String[] {KEY_ROWID },
						null, null, null, null, null);
			if (c.moveToFirst())
			{
			 	do {
			   		db.execSQL("DROP TABLE IF EXISTS " + c.getInt(0) + ";");
			   	} while (c.moveToNext());
			}	
			db.execSQL("DROP TABLE IF EXISTS locations;"); // Drop locations table
								// ?? Check VACUUM??
			onCreate(db);
		}
	} 	
	//------------------------------------------------------------------------------------------
	// Opens the database	
	public DBAdapter open() throws SQLException 
	{
		db = DBHelper.getWritableDatabase();
		return this;
	}
	
	// Closes the database	
	public void close()
	{
		DBHelper.close();
	}
	// Insert a location in the database
	public long insertLoc(String place, String tz, double latitude, double longitude, int year)
	{
		
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_PLACE, place);
		initialValues.put(KEY_TZ, tz);
		initialValues.put(KEY_LAT, latitude);
		initialValues.put(KEY_LONG, longitude);
		initialValues.put(KEY_YEAR, year);
		return db.insert(DATABASE_TABLE, null, initialValues);
	}
	// Delete a location in the database
	public boolean deleteLoc(long rowid) {
		return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowid, null) > 0;
	}
	// Retrieve all locations
	public Cursor getAllLocs()
	{
		return db.query(DATABASE_TABLE, new String[] {KEY_ROWID, KEY_PLACE, KEY_TZ, KEY_LAT, KEY_LONG, KEY_YEAR},
				null, null, null, null, null);
	}
	// Retrieve a location
	public Cursor getLoc(long rowid) throws SQLException
	{
		Cursor mCursor = db.query(true, DATABASE_TABLE, 
				new String[] {KEY_ROWID, KEY_PLACE, KEY_TZ, KEY_LAT, KEY_LONG, KEY_YEAR},
				KEY_ROWID + "=" + rowid, null, null, null, null, null);
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}
//-----------------------------------------------------------------------------------------------
// Note: Table name 2 etc is not accepted by SQLite. Has to be L2 for example.
	public void crYTable(String yt)
	{
		String dbYCr ="create table " + yt + " (_id integer primary key autoincrement, " +
				"month integer not null, day integer not null, " +
				"hup integer not null, mup integer not null, " +
				"hdown integer not null, mdown integer not null, " +
				"hlen integer not null, mlen integer not null, " +
				"elev real not null, aziup real not null, azidown real not null);";
		try {
			db.execSQL(dbYCr);
		} catch (SQLException e) {
			e.printStackTrace();		
		}
	}
	public void deleteYTable(String yt)
	{
		db.execSQL("DROP TABLE IF EXISTS " + yt + ";");
	}
//	solar data in arrays - inserted in one transaction
	public void insertYear(String yt, int numd, int month[], int day[], int hup[], int mup[], 
			int hdown[], int mdown[], int hlen[], int mlen[], double elev[], double aziup[], double azidown[])
	{
		ContentValues initialValues = new ContentValues();
		try{
			db.beginTransaction();
			for (int i = 0; i <= numd; i++) {
				initialValues.put(KEY_MONTH, month[i]);
				initialValues.put(KEY_DAY, day[i]);
				initialValues.put(KEY_HUP, hup[i]);
				initialValues.put(KEY_MUP, mup[i]);
				initialValues.put(KEY_HDOWN, hdown[i]);
				initialValues.put(KEY_MDOWN, mdown[i]);
				initialValues.put(KEY_HLEN, hlen[i]);
				initialValues.put(KEY_MLEN, mlen[i]);
				initialValues.put(KEY_ELEV, elev[i]);
				initialValues.put(KEY_AZIUP, aziup[i]);
				initialValues.put(KEY_AZIDOWN, azidown[i]);
				db.insert(yt, null, initialValues);
			}
		db.setTransactionSuccessful();
		} catch (SQLException e) {
		} finally {
			db.endTransaction();
		}
	}
	// Retrieve all locations
	public Cursor getAllDays(String yt)
	{
		return db.query(yt, new String[] {KEY_ROWID, KEY_MONTH, KEY_DAY, KEY_HUP, KEY_MUP,
				KEY_HDOWN, KEY_MDOWN, KEY_HLEN, KEY_MLEN, KEY_ELEV, KEY_AZIUP, KEY_AZIDOWN},
				null, null, null, null, null);
	}
	// Retrieve a day 
	public Cursor getADay(String yt, long id) 
	{
		Cursor mCursor;
		mCursor = db.query(yt, new String[] {KEY_ROWID, KEY_MONTH, KEY_DAY, KEY_HUP, KEY_MUP, 
					KEY_HDOWN, KEY_MDOWN, KEY_HLEN, KEY_MLEN, KEY_ELEV, KEY_AZIUP, KEY_AZIDOWN},
					KEY_ROWID + "=" + id, null, null, null, null);
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}
	
}
