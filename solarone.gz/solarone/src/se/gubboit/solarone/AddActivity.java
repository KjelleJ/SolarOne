//-----------------------------------------------------------------------------
// AddActivity.java
//
// 2012-2014 GubboIT
//
// 2014-01-30 Auto mode added
// 2013-11-11 Only portrait for phone
// 2013-11-10 Handle screen orientation
// 2013-03-31 tz id and DST info saved in DB
// 2013-03-27 DST added
// 2013-03-23 Spinner added to lookup tz
// 2013-03-23 Toast replaced by dialog
// 2013-03-22 Allow for tz as hh:mm. Example: India +5:30.
// 2013-03-21 Faster insert of solar data into db
// 2013-03-20 numberSigned added to lat and lng fields (addactivity.xml) to allow for negative values
// 2013-03-20 Rejkjavik fix - sunset after midnight...
// 2012-02-26 No Set=24:00. Should be 00:00
//			  azidown = 360 - aziup
// 2012-04-13 Removed hints in xml-file for lat, long, and tz (confusing if no value added)
// 2012-02-25 OK means back to My Places
// 2012-02-24 Some nw access in background to fix NetworkOnMainThreadException (Honeycomb)
// 2012-02-23 Specific intents (are simpler to use)
// 2012-02-22 First version
//-----------------------------------------------------------------------------
package se.gubboit.solarone;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;

import uk.me.jstott.coordconv.LatitudeLongitude;
import uk.me.jstott.sun.Sun;
import uk.me.jstott.sun.Time;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

public class AddActivity extends Activity {
	double latitude, longitude;
	private int year;

	//int timezone;
	String strTz;
	String tzId =""; // timezone id
	String dstOff; // DST offset +h:mm
	EditText txtTimezone;
	EditText txtYear;
	EditText txtPlace;
	EditText txtLatitude;
	EditText txtLongitude;
	TextView txtDSTStart;
	TextView txtDSTEnd;
	TextView txtDSTOffset;
	CheckBox chkDST;
	CheckBox chkAuto;
	Button btnok;
	Button btntz;
	Button btncoord;
	Button btnDSTStart;
	Button btnDSTEnd;
	Button btnDSTOff;
	boolean addDST;
	boolean auto;
	int dt1dn , dt2dn;
	String [] monN = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
	private ProgressBar progressbar;
	DBAdapter db = new DBAdapter(this);
	
	private class BackgroundTask extends AsyncTask <Long, Void, Integer> {
		// NOTE: Void means not used!!!
		protected Integer doInBackground(Long... id) {
			populateYT(id[0]);
			return 0;
		}
		protected void onPostExecute(Integer result) {
			Intent data = new Intent();
			data.setData(Uri.parse(Double.toString(latitude) + "," + Double.toString(longitude)));
			setResult(RESULT_OK, data);
			finish();
		}
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addactivity);
		Calendar cal = Calendar.getInstance();
		year = cal.get(Calendar.YEAR); // always current year
		//txtYear = (EditText) findViewById(R.id.txtYear);
		//txtYear.setText(Integer.toString(cal.get(Calendar.YEAR)));
		btnok = (Button)findViewById(R.id.btnOK);
		btnok.setOnClickListener(btnOKListener);
		btntz = (Button)findViewById(R.id.btnTZ);
		btntz.setOnClickListener(btnTZListener);
		btncoord = (Button)findViewById(R.id.btnCoord);
		btncoord.setOnClickListener(btnCoordListener);
		btnDSTStart = (Button)findViewById(R.id.btnDSTStart);
		btnDSTStart.setOnClickListener(btnDSTListener);
		btnDSTEnd = (Button)findViewById(R.id.btnDSTEnd);
		btnDSTEnd.setOnClickListener(btnDSTListener);
		btnDSTOff = (Button)findViewById(R.id.btnDSTOffset);
		btnDSTOff.setOnClickListener(btnDSTOffListener);	

		txtPlace = (EditText) findViewById(R.id.txtPlace);
		txtLatitude = (EditText) findViewById(R.id.txtLatitude);
		txtLongitude = (EditText) findViewById(R.id.txtLongitude);			
		txtTimezone = (EditText) findViewById(R.id.txtTimezone);
		txtDSTStart = (TextView) findViewById(R.id.txtDSTStart);
		txtDSTEnd = (TextView) findViewById(R.id.txtDSTEnd);
		txtDSTOffset = (TextView) findViewById(R.id.txtDSTOffset);
		chkDST = (CheckBox) findViewById(R.id.chkDST);
		chkAuto = (CheckBox) findViewById(R.id.chkAuto);
		if (!getResources().getBoolean(R.bool.isTablet))
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); // portrait only for phone
		auto = chkAuto.isChecked();
		setAuto();
		chkAuto.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			   @Override
			   public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
				   auto = isChecked;
				   setAuto();
			   }
			});
	} 
	
	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putString("DSToff", txtDSTOffset.getText().toString());
		outState.putString("DSTstart", txtDSTStart.getText().toString());
		outState.putString("DSTend", txtDSTEnd.getText().toString());
		outState.putString("TZId", tzId);
		super.onSaveInstanceState(outState);
	}
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		txtDSTOffset.setText(savedInstanceState.getString("DSToff"));
		txtDSTStart.setText(savedInstanceState.getString("DSTstart"));
		txtDSTEnd.setText(savedInstanceState.getString("DSTend"));
		tzId = savedInstanceState.getString("TZId");
	}

	private OnClickListener btnCoordListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			String place = txtPlace.getText().toString();
			if (place.length() == 0) {
				errMess("No value in field Place");
				return;
			}
			Intent i = new Intent(AddActivity.this, AddMap.class);
			i.putExtra("place", place);

			startActivityForResult(i, 1);
		}
	};
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (requestCode == 1) {
			if (resultCode == RESULT_OK) {
				String latlong = data.getData().toString();
				String slat = latlong.substring(0, latlong.indexOf(","));
				String slong = latlong.substring(latlong.indexOf(",") + 1, latlong.length());
				txtLatitude.setText(slat);
				txtLongitude.setText(slong);
				if (auto)
					getTz();
			}
		}
	}

	private OnClickListener btnTZListener = new OnClickListener()
	{
		public void onClick(View v)
		{		
			getTz();
			return;		
		}
	};
	private void getTz() {
		String txt = "";
		try {
			txt = "latitude";
			latitude = Double.parseDouble(txtLatitude.getText().toString());
			if (latitude > 90.0 || latitude < -90.0) {
				errMess("Latitude must be in interval (-90, +90)");
				return;
			}
			txt = "longitude";
			longitude = Double.parseDouble(txtLongitude.getText().toString());
			if (longitude > 180.0 || longitude < -180.0) {
				errMess("Longitude must be in interval (-180, +180)");
				return;
			}
		}
		catch(NumberFormatException e) {
			errMess("Bad input in field " + txt);
			return;
		}
		// Get timezone from Google Time Zone API
		//xml?location=39.6034810,-119.6822510&timestamp=1331161200&sensor=true_or_false
		Calendar cal = Calendar.getInstance();
		progressbar = (ProgressBar) findViewById(R.id.progressbar);
		progressbar.setVisibility(ProgressBar.VISIBLE);
		// to get a valid DST offset value use a time stamp around mid summer in the north
		// and around mid winter in the south
		if (latitude >= 0.0) {
			cal.set(year, 6, 22);
		} else {
			cal.set(year, 12, 22);
		}
		new BackgroundTask2().execute("https://maps.googleapis.com/maps/api/timezone/xml?location=" +
				Double.toString(latitude) +"," + Double.toString(longitude) + "&timestamp=" + 
				cal.getTimeInMillis()/1000L + "&sensor=false");
		return;		
	}
	private class BackgroundTask2 extends AsyncTask <String, Void, String> {
		protected String doInBackground(String... string) {
			return lookuptz(string[0]);
		}
		protected void onPostExecute(String result) {
			progressbar.setVisibility(ProgressBar.INVISIBLE);
			txtTimezone.setText(result);
			txtDSTOffset.setText(dstOff);
			getDST();
		}
	}
	
	private OnClickListener btnOKListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			//double latitude, longitude;
			//int year;
			String txt = "";
			String place; 
			String timezone;
			boolean indDST = false; // DST checked by not applicable
			dstOff = txtDSTOffset.getText().toString();
			if (chkDST.isChecked())
				addDST = true;
			else
				addDST = false;
			try {
				txt = "Latitude";
				latitude = Double.parseDouble(txtLatitude.getText().toString());
				if (latitude > 90.0 || latitude < -90.0) {
					errMess("Latitude must be in interval (-90, +90)");
					return;
				}
				txt = "Longitude";
				longitude = Double.parseDouble(txtLongitude.getText().toString());
				if (longitude > 180.0 || longitude < -180.0) {
					errMess("Longitude must be in interval (-180, +180)");
					return;
				}
				//txt = "Year";
				//year = Integer.parseInt(txtYear.getText().toString());
				txt = "Timezone";			
				timezone = txtTimezone.getText().toString().trim();
				{
					int tzh = 99, tzm = 0, sign = +1;
					Pattern p = Pattern.compile("(^[+-]?)(\\d+)(:(\\d+))?$");
					Matcher m = p.matcher(timezone);
					if (m.matches()) {
						if (timezone.charAt(0) == '-')
							sign = -1;
						tzh = Integer.parseInt(m.group(2), 10);
						tzh = sign*tzh;
						if (m.group(4) != null)
							tzm = Integer.parseInt(m.group(4), 10);
					}
					if (tzh > 15 || tzh < -12 || tzm > 59) {
						errMess("Timezone must be [+|-]hh[:mm] where hh is (-12,+15). Examples: 5, +5:30, -5");
						return;	
					}
				}
			}
			catch(NumberFormatException e) {
				errMess("Bad input in field " + txt);
				return;
			}
			
			place = txtPlace.getText().toString();
			if (place.length() == 0) {
				errMess("No value in field Place");
				return;
			}
			// check DST start and end and DST offset (may be modified by user)
			if (addDST && txtDSTOffset.getText().equals("+0:00")) {
				indDST = true; // DST not applicable
				addDST = false;
			}
			if (addDST) {
				String dstStart, dstEnd, dstOffset;
				dstStart = (String)txtDSTStart.getText().toString();
				dstEnd = (String)txtDSTEnd.getText().toString();
				dstOffset = (String)txtDSTOffset.getText().toString();
				if (dstOffset.length() == 0 || dstStart.length() == 0 || dstEnd.length() == 0) {
					errMess("Value missing in DST field");
					return;
				}
				dt1dn = getDayno(dstStart);
				dt2dn = getDayno(dstEnd);
				if (latitude >= 0.0) {
					if( dt1dn >= dt2dn) {
						errMess("DST Start must be before DST End");
						return;
					}
				} else { // latitude < 0.0
					if( dt2dn >= dt1dn) {
						errMess("DST Start must be after DST End");
						return;
					}
				}
			}
			// Create and populate table with values for a whole year
			db.open();
			String sign = "-";
			if (timezone.charAt(0) == '+' || timezone.charAt(0) == '-')
				sign = "";
			strTz = "GMT" + sign + timezone;
			if (addDST || indDST)
				place = place + " *";
			// 1) tz 2) tz id 3) DST offset 4) DST start 5) DST end		
			String  tzInfo = strTz + "#" + tzId + "#" + (String)txtDSTOffset.getText().toString() + "#" +
					(String)txtDSTStart.getText().toString() + "#" + (String)txtDSTEnd.getText().toString() + "#";
			long id = db.insertLoc(place, tzInfo, latitude, longitude, year);
			if (id >= 0) {
				progressbar = (ProgressBar) findViewById(R.id.progressbar);
				progressbar.setVisibility(ProgressBar.VISIBLE);
				db.crYTable("L" + id);
				btnok.setEnabled(false);
				btntz.setEnabled(false);
				btncoord.setEnabled(false);
				new BackgroundTask().execute(id); // Populate table in background
			}
		};	
	};

	void populateYT(long id) {
		int monthA[] = new int[366];
		int dayA[] = new int[366];
		int hupA[] = new int[366];
		int mupA[] = new int[366];
		int hdownA[] = new int[366];
		int mdownA[] = new int[366];
		int hlenA[] = new int[366];
		int mlenA[] = new int[366];
		double elevA[] = new double[366];
		double aziupA[] = new double[366];
		double azidownA[] = new double[366];
		int numd = 0;

		// Add sun values for a year
		LatitudeLongitude ll = new LatitudeLongitude(latitude, longitude);
		TimeZone tz = TimeZone.getTimeZone(strTz);
		Calendar cal = Calendar.getInstance();
		boolean dst = false;
		Time tUp, tDown;
		int nzh;
		int hup, mup, hdown, mdown, hlen, mlen;
		int dsthh = 0, dstmm = 0;
		int sup, sdown, slen;
		double elev, aziup, azidown; // azimuth for sun rise/set
		
		if (latitude >= 0) // In the north...
			nzh = 1;
		else
			nzh = 23; // Could be midnight sun in the first day of the year
		cal.set(year,0,1); // First day of year
		if (addDST) { // handle DST
			// dstOff = +h:mm
			dsthh = Integer.parseInt(dstOff.substring(1, 2));
			dstmm = Integer.parseInt(dstOff.substring(3, 5));	
		}
		do { // Strange jan is 0!!!
			tUp = Sun.sunriseTime(cal, ll, tz, dst);
			hup = tUp.getHours();
			mup = tUp.getMinutes();
			sup = (int)tUp.getSeconds();
			//tround(hup, mup, sup);
			if (sup > 30) {
				mup++;
				if (mup == 60) {
					mup = 0;
					hup++;
					if (hup == 24)
						hup = 0;
				}
			}

			tDown = Sun.sunsetTime(cal, ll, tz, dst);
			hdown = tDown.getHours();
			mdown = tDown.getMinutes();
			sdown = (int)tDown.getSeconds();
			//tround(hdown, mdown, sdown);
			if (sdown > 30) {
				mdown++;
				if (mdown == 60) {
					mdown = 0;
					hdown++;
					if (hdown == 24)
						hdown = 0;
				}
			}

			// Calculate length
			// THIS PART SHOULD BE REWRITTEN!!!!
			if (hdown - hup > 0)
				nzh = hdown - hup; // Is last diff long or short?
			if (hdown == 0 &&  mdown == 0 && nzh > 20)  // 0:0:0 is here 24:0:0
				hdown = 24;
			// Rejkjavik fix - sunset after midnight...
			if (hdown - hup < 0)
				hdown = 24;
			slen = hdown*3600 + mdown*60 + sdown - (hup*3600 + mup*60 + sup);
			if (hdown == 24)
				hdown = 0; // reset to 00:00
			hlen = slen/3600;
			mlen = (slen - hlen*3600)/60;
			slen = (slen - hlen*3600 - mlen*60);
			//tround(hlen, mlen, slen);
			if (slen > 30) {
				mlen++;
				if (mlen == 60) {
					mlen = 0;
					hlen++;
					if (hlen > 24)
						hlen = 24;
				}
			}
			// Adjust for DST after length calculation....
			if (addDST && hlen < 24) { // not midnight sun 
				if (latitude >= 0.0) {
					if (numd + 1 >= dt1dn && numd + 1 < dt2dn) {
						if (hlen < 23 || hup != 0 || mup != 0) {
							hup = hup + dsthh;
							mup = mup + dstmm;
						}
						if (hlen < 23 || hdown != 0 || mdown != 0) {
							hdown = hdown + dsthh;
							mdown = mdown + dstmm;
						}
					}
				} else {
					if (numd + 1 < dt2dn || numd + 1 >= dt1dn) {
						if (hlen < 23 || hup != 0 || mup != 0) {
							hup = hup + dsthh;
							mup = mup + dstmm;
						}
						if (hlen < 23 || hdown != 0 || mdown != 0) {
							hdown = hdown + dsthh;
							mdown = mdown + dstmm;
						}
					}		
				}
				if (mup >= 60) {
					hup = hup + 1;
					mup = mup - 60;
				}
				if (hup >= 24)
					hup = hup - 24;
				if (mdown >= 60) {
					hdown = hdown + 1;
					mdown = mdown - 60;
				}
				if (hdown >= 24)
					hdown = hdown - 24;
			}
			elev = Sun.sunNoonElevation(cal, ll, tz);
			aziup = Sun.azimuthSunRise(cal, ll, tz);
			//azidown = Sun.azimuthSunSet(cal, ll, tz);
			azidown = 360.0 - aziup; // saves computing time!	
			// save solar data in arrays
			monthA[numd] = cal.get(Calendar.MONTH) + 1;
			dayA[numd] = cal.get(Calendar.DAY_OF_MONTH);
			hupA[numd] = hup;
			mupA[numd] = mup;
			hdownA[numd] = hdown;
			mdownA[numd] = mdown;
			hlenA[numd] = hlen;
			mlenA[numd] = mlen;
			elevA[numd] = elev;
			aziupA[numd] = aziup;
			azidownA[numd] = azidown;
			numd++;
			cal.add(Calendar.DAY_OF_YEAR,1);
		} while (cal.get(Calendar.YEAR)==year);
		// insert solar data (the arrays) in one transaction
		db.insertYear("L" + id, --numd, monthA, dayA, 
				hupA, mupA, hdownA, mdownA,
				hlenA, mlenA, elevA, aziupA, azidownA);
		db.close();
	}
	// returns null or raw offset as +/-hh:mm
	private String lookuptz(String urlString)
	{
		InputStream in = null;
		String tz = "";
		dstOff = "";
		tzId = "";
		try {
			in = OpenHttpConnection(urlString);
			Document doc = null;
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db;
			try {
				db = dbf.newDocumentBuilder();
				doc = db.parse(in);
			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			doc.getDocumentElement().normalize();		
			String status = doc.getElementsByTagName("status").item(0).getFirstChild().getNodeValue();
			if (status.compareToIgnoreCase("OK") == 0) {
				tz = getHhmm((int)(Double.parseDouble(doc.getElementsByTagName("raw_offset").item(0).getFirstChild().getNodeValue())));
				dstOff = getHhmm((int)(Double.parseDouble(doc.getElementsByTagName("dst_offset").item(0).getFirstChild().getNodeValue())));
				tzId = doc.getElementsByTagName("time_zone_id").item(0).getFirstChild().getNodeValue();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return tz;
	}
	private InputStream OpenHttpConnection(String urlString) throws IOException
	{
		InputStream in = null;
		URL url;
		int response = -1;
		url = new URL(urlString);
		URLConnection conn = url.openConnection();
		if (!(conn instanceof HttpURLConnection))
			throw new  IOException("Not an HTTP connection");
		try {
			HttpURLConnection httpConn = (HttpURLConnection)conn;
			httpConn.setAllowUserInteraction(false);
			httpConn.setInstanceFollowRedirects(true);
			httpConn.setRequestMethod("GET");
			httpConn.connect();
			response = httpConn.getResponseCode();
			if (response == HttpURLConnection.HTTP_OK) 
				in = httpConn.getInputStream();
		} 
		catch (Exception ex)
		{
			throw new IOException("Error connecting");
		}
		return in;
	}
	private void errMess(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Add Place");
		builder.setPositiveButton("OK", null);
		builder.setMessage(message);
		AlertDialog infoDialog = builder.create();
		infoDialog.show();
	}
	// returns +|-hh:mm from a value in seconds
	private String getHhmm(int secVal) {
		int tzs, tzm, tzh;
		tzs = secVal;
		String sign = "+", zero = "";
		if (tzs < 0) {
			sign = "-";
			tzs = -tzs;
		}
		tzh = tzs/3600;
		tzm = (tzs - tzh*3600)/60;
		if (tzm < 10) 
			zero = "0";
		return sign + tzh + ":" + zero + tzm;
	}
	// get dayno from date string like MAY20
	private int getDayno(String date) {
		int mon, day;
		Calendar cal = Calendar.getInstance();
		for (mon = 0; mon < 12; mon++) {
			if (date.startsWith(monN[mon]))
				break;
		}
		day = Integer.parseInt(date.substring(3), 10);
		cal.set(year, mon, day);
		return cal.get(Calendar.DAY_OF_YEAR);
	}
	// Joda gives start and end of daylight saving
	private void getDST() {
       	DateTime dt1, dt2;
       	DateTimeZone dtz;
       	int dt1y, dt2y;
		txtDSTStart.setText("");
		txtDSTEnd.setText("");
       	if (dstOff.equals("+0:00") || tzId.length() == 0) { 
       		// Google tz API says no DST or no tz id
			return;
  		} 
       	dtz = DateTimeZone.forID(tzId);
       	if (dtz.isFixed()) { // should not happen!?
       		// Google tz api says DST but not Joda...
         	errMess("DST start and end unknown.");
			return;
       	}
       	if (latitude >= 0.0) {
       		dt1 = new DateTime(dtz.nextTransition(new DateTime(year, 1, 1, 0, 0, 0, 0, dtz).getMillis()));
       		dt2 = new DateTime(dtz.previousTransition(new DateTime(year + 1, 1, 1, 0, 0, 0, 0, dtz).getMillis()));
       	} else { // why must I add one day????
       		dt1 = new DateTime(dtz.nextTransition(
       				new DateTime(year, 6, 20, 0, 0, 0, 0, dtz).getMillis()) + 24*3600*1000);
       		dt2 = new DateTime(dtz.previousTransition(
       				new DateTime(year, 6, 20, 0, 0, 0, 0, dtz).getMillis()) + 24*3600*1000);
       	}
        dt1y = dt1.getYear();
        dt2y = dt2.getYear();
        if (dt1y == year && dt2y == year) {
        	txtDSTStart.setText(monN[dt1.getMonthOfYear() - 1] +  dt1.getDayOfMonth());
        	txtDSTEnd.setText(monN[dt2.getMonthOfYear() - 1] +  dt2.getDayOfMonth());
        } else {
          	errMess("DST start and end unknown.");
        }
        return;
	}
	private OnClickListener btnDSTOffListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			final String[] selVal = getResources().getStringArray(R.array.dstoff);	
			AlertDialog.Builder setBuilder = new AlertDialog.Builder(AddActivity.this);
			setBuilder.setTitle("Set DST Offset");
			setBuilder.setItems(R.array.dstoff, new android.content.DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int item)
				{
					dstOff = selVal[item];
					txtDSTOffset.setText(dstOff);
				}
			}
			);
			AlertDialog setDialog = setBuilder.create();
			setDialog.show();
		}
	};
	private OnClickListener btnDSTListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			final String[] selVal = {"MAR1", "MAR2", "MAR3", "MAR4", "MAR5", "MAR6", "MAR7", "MAR8", "MAR9", "MAR10",
					"MAR11", "MAR12", "MAR13", "MAR14", "MAR15", "MAR16", "MAR17", "MAR18", "MAR19", "MAR20",
					"MAR21", "MAR22", "MAR23", "MAR24", "MAR25", "MAR26", "MAR27", "MAR28", "MAR29", "MAR30", "MAR31",
					"APR1", "APR2", "APR3", "APR4", "APR5", "APR6", "APR7", "APR8", "APR9", "APR10",
					"APR11", "APR12", "APR13", "APR14", "APR15", "APR16", "APR17", "APR18", "APR19", "APR20",
					"APR21", "APR22", "APR23", "APR24", "APR25", "APR26", "APR27", "APR28", "APR29", "APR30",
					"MAY1", "MAY2", "MAY3", "MAY4", "MAY5", "MAY6", "MAY7", "MAY8", "MAY9", "MAY10",
					"MAY11", "MAY12", "MAY13", "MAY14", "MAY15",
					"SEP1", "SEP2", "SEP3", "SEP4", "SEP5", "SEP6", "SEP7", "SEP8", "SEP9", "SEP10",
					"SEP11", "SEP12", "SEP13", "SEP14", "SEP15", "SEP16", "SEP17", "SEP18", "SEP19", "SEP20",
					"SEP21", "SEP22", "SEP23", "SEP24", "SEP25", "SEP26", "SEP27", "SEP28", "SEP29", "SEP30",
					"OCT1", "OCT2", "OCT3", "OCT4", "OCT5", "OCT6", "OCT7", "OCT8", "OCT9", "OCT10",
					"OCT11", "OCT12", "OCT13", "OCT14", "OCT15", "OCT16", "OCT17", "OCT18", "OCT19", "OCT20",
					"OCT21", "OCT22", "OCT23", "OCT24", "OCT25", "OCT26", "OCT27", "OCT28", "OCT29", "NOV30",
					"NOV1", "NOV2", "NOV3", "NOV4", "NOV5", "NOV6", "NOV7", "NOV8", "NOV9", "NOV10",
					"NOV11", "NOV12", "NOV13", "NOV14", "NOV15"};
			
			final TextView textView;
			String text;
			
			if (v == btnDSTStart) {
				text = "Set DST Start";
				textView = txtDSTStart;
			} else {
				text = "Set DST End";
				textView = txtDSTEnd;
			}
			AlertDialog.Builder setBuilder = new AlertDialog.Builder(AddActivity.this);
			setBuilder.setTitle(text);
			setBuilder.setItems(selVal, new android.content.DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int item)
				{
					textView.setText(selVal[item]);
				}
			}
			);
			AlertDialog setDialog = setBuilder.create();
			setDialog.show();
		}
	};
	// Hides buttons if auto-fill
	private void setAuto() {
		int visible;
		if (!auto) {
			visible = View.VISIBLE;
			btncoord.setText("2) Get Coordinates");
		} else {
			btncoord.setText("Get Values");
			visible = View.GONE;
		}
		btntz.setVisibility(visible);
		btnDSTStart.setVisibility(visible);
		btnDSTEnd.setVisibility(visible);
		btnDSTOff.setVisibility(visible);	
	}
}


