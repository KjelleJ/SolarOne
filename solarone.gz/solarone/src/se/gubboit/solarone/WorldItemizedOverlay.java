//-----------------------------------------------------------------------------
// WorldItemizedOverlay.java
//
// 2013-2014 GubboIT
//
// 2013-04-02 First version
//-----------------------------------------------------------------------------
package se.gubboit.solarone;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class WorldItemizedOverlay extends ItemizedOverlay {
	Context mContext;
	MapView myMapView = null;
	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
	public WorldItemizedOverlay(Drawable defaultMarker) {
		super(boundCenterBottom(defaultMarker));
		// TODO Auto-generated constructor stub
	}

	@Override
	protected OverlayItem createItem(int i) {
		return mOverlays.get(i);
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return mOverlays.size();
	}
	public void addOverlay(OverlayItem overlay) {
	    mOverlays.add(overlay);
	    populate();
	}
	public void clear() {
		mOverlays.clear();
	}
	public WorldItemizedOverlay(Drawable defaultMarker, Context context) {
		  super(boundCenterBottom(defaultMarker));
		  mContext = context;
	}
	// just to get mapView to invalidate in onTap!
	@Override
	public
	boolean onTouchEvent(MotionEvent event, MapView mapView) {
		myMapView = mapView;
		return false;
	}
	@Override
	protected boolean onTap(int index) {
		final int ix = index;
		final OverlayItem item = mOverlays.get(index);
		AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
		dialog.setTitle(item.getTitle());
		dialog.setMessage(item.getSnippet());
	    dialog.setNegativeButton("Cancel", null);
	    dialog.setPositiveButton("Toggle Selection", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (WorldMap.checked.get(ix)) { // selected -> not selected 
					WorldMap.checked.set(ix, false);
					item.setMarker(WorldMap.drawableY);
				} else {
					WorldMap.checked.set(ix, true);
					item.setMarker(WorldMap.drawableR);
				}
				if (myMapView != null)
					myMapView.invalidate();
				dialog.dismiss();
			}
		});
	 	dialog.show();
	 	return false;
	}
}
