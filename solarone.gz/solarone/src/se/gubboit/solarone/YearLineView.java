//-----------------------------------------------------------------------------
// YearLineView.java
//
// 2012 GubboIT
//
// 2013-11-02 Scale yearline
// 2012-02-22 First version
//-----------------------------------------------------------------------------

package se.gubboit.solarone;

import java.util.Calendar;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.Paint.Style;
import android.view.View;

public class YearLineView extends View {
	private Bitmap cache;
	private int year; 
	private int scale;
	private int width = 30;
	private float textsize = 20f;
	private static final String [] monax = { "J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"};
	
	public YearLineView(Context context, int year) { // Constructor
		super(context);
		this.year = year;
		scale = WorldMap.scale;
		if (scale > 1) {
			width *= scale;
			textsize *= scale;
		}
		setMinimumWidth(width + scale*10);
		setMinimumHeight(scale*(2*366+4));
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		setMeasuredDimension(getSuggestedMinimumWidth(),
			getSuggestedMinimumHeight());
	}
	@Override
	protected void onDraw(Canvas canvas) {
		int day, month;
		if (cache == null) { // Create and draw bitmap
			cache = Bitmap.createBitmap(getMeasuredWidth(), getMeasuredHeight(),
					Bitmap.Config.ARGB_8888);
			Paint paint = new Paint();
			paint.setTextSize(textsize);
			paint.setFakeBoldText(true);
			paint.setTypeface(Typeface.MONOSPACE); // Otherwise J is always I!
			paint.setAntiAlias(true);
			paint.setStyle(Style.FILL);
			paint.setColor(Color.RED);
			Canvas bmpCanvas = new Canvas(cache);
			Calendar plcal = Calendar.getInstance();
			for (month = 0; month <= 11; month++) {
				plcal.set(year, month, 1); // First day of month
				day = plcal.get(Calendar.DAY_OF_YEAR);
				bmpCanvas.drawLine(0, scale*2*day, width, scale*2*day, paint); // Draw month line
				day += 20;
				bmpCanvas.drawText(monax[month], 0, scale*2*day, paint); // Draw month letter
			}
			day = plcal.getMaximum(Calendar.DAY_OF_YEAR);
			bmpCanvas.drawLine(0, scale*2*day, width, scale*2*day, paint); // Draw month line for last day of year
		}
		Paint paint = new Paint();
		canvas.drawBitmap(cache, scale*20, 0, paint); // Just use saved bitmap
		invalidate();
	}
	
}


