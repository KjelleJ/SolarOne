//-----------------------------------------------------------------------------
// WorldMap.java
//
// 2013-2014 GubboIT
//
// 2014-01-30 Old main replaced by WorldMap
// 2013-11-11 Only portrait for phone 
// 2013-04-01 First version
//-----------------------------------------------------------------------------

package se.gubboit.solarone;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.Overlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class WorldMap extends MapActivity {
	MapView mapView;
	MapController mc;
	private AlertDialog alertDialog;
	private List<Long> ids;
	private List<String> places;
	private List<String> infos;
	private List<Double> lats;
	private List<Double> lngs;
	static List<Boolean> checked;
	static Drawable drawableY;
	static Drawable drawableR;
	private String strChecked = "";;
	List<Overlay> mapOverlays;
	WorldItemizedOverlay itemizedOverlay;
	//private int zoomLevel = 0;
	public static int scale = 1;
	private boolean greeting;
	private int numPxH, numPxW;
	private boolean satellite = false;

	static ActivityManager instance;

	public static ActivityManager getInstance() {
	    return instance;
	}
	// Funkar inte alltid att spara h�r eftersom onRestore
	// inte alltid anropas.... Anv prefs????
	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		//Log.d("SolarOne", "onSaveInstanceState");
		strChecked = "";
		for (int i = 0; i < checked.size(); i++) {
			if (checked.get(i))
				strChecked += "1";
			else
				strChecked += "0";
		}
		outState.putString("checked", strChecked);
		outState.putBoolean("satellite", satellite);
	}
	// called after onStart()
	// Note: only called if needed but when is that?
	// Works after rotation...
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		//Log.d("SolarOne", "onRestoreInstanceState");
		super.onRestoreInstanceState(savedInstanceState);
		satellite = savedInstanceState.getBoolean("satellite");
		strChecked = savedInstanceState.getString("checked");
		for (int i = 0; i < checked.size(); i++) 
			checked.set(i, (strChecked.charAt(i) == '1'));
		setBallons();
	}
	
	// onPause
	@Override
	public void onPause() {
		//Log.d("SolarOne", "onPause");
		if (alertDialog != null)
			alertDialog.dismiss(); // no WindowLeaked
		super.onPause();
	}

	// onResume
	@Override
	public void onResume() {
		SharedPreferences prefs;
		//Log.d("SolarOne", "onResume");
		super.onResume();
		mapView.setSatellite(satellite);
		mc.setZoom(getResources().getInteger(R.integer.worldZoom));
		mc.animateTo(new GeoPoint(10*1000000, 0));
		//----
		prefs = getSharedPreferences("mypref", MODE_PRIVATE);
		// Greeting until the first place is defined...
		if(checked.size() > 0 && greeting) {
			greeting = false;	
			SharedPreferences.Editor editor = prefs.edit();
			editor.putBoolean("greeting", false);
			editor.commit();
		}
		if(checked.size() == 0 && greeting) { 
			// Copy database of predefined places 
			try {				 
			   	//Open your local db as the input stream
		    	InputStream myInput = getAssets().open("soldb");
		 
		    	// Path to the just created empty db (getFilesDir().getPath() does not work)
		    	String outFileName = "/data/data/se.gubboit.solarone/databases/" + "soldb";
		    	//Open the empty db as the output stream
		    	OutputStream myOutput = new FileOutputStream(outFileName);
		 
		    	//transfer bytes from the inputfile to the outputfile
		    	byte[] buffer = new byte[1024];
		    	int length;
		    	while ((length = myInput.read(buffer))>0){
		    		myOutput.write(buffer, 0, length);
		    	}
		 
		    	//Close the streams
		    	myOutput.flush();
		    	myOutput.close();
		    	myInput.close();
    		} catch (IOException e) {
        		throw new Error("Error copying database");
        	} 
			setPlaces();
			setBallons();
			// Show info dialog
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Welcome to SolarOne!");
			builder.setPositiveButton("OK", null);
			builder.setIcon(R.drawable.ic_launcher_solarone);
			builder.setMessage("SolarOne calculates and shows solar data for any place on earth. " +
						"5 places are predefined. " +
						"Please read Help or just start...");
			AlertDialog infoDialog = builder.create();
			infoDialog.show();
		}
	}
	@Override
	public void onCreate(Bundle savedInstanceState) {
		SharedPreferences prefs;	
		//Log.d("SolarOne", "onCreate");
		super.onCreate(savedInstanceState);
		ids = new ArrayList<Long>();
		places = new ArrayList<String>();
		infos = new ArrayList<String>();
		checked = new ArrayList<Boolean>();
		lats = new ArrayList<Double>();
		lngs = new ArrayList<Double>();	
		setContentView(R.layout.worldmap);
		mapView = (MapView) findViewById(R.id.worldmap);
		mc = mapView.getController();
		mapView.setBuiltInZoomControls(true);
		// setBounds is important. Otherwise the ballon disappears when tapped!
		drawableY = this.getResources().getDrawable(R.drawable.ballony);
		//drawableY.setBounds(0, 0, drawableY.getIntrinsicWidth(), drawableY.getIntrinsicHeight()); 
		drawableY.setBounds(-drawableY.getIntrinsicWidth()/2, -drawableY.getIntrinsicHeight(), drawableY.getIntrinsicWidth()/2, 0); 
		drawableR = this.getResources().getDrawable(R.drawable.ballonr);
		//drawableR.setBounds(0, 0, drawableR.getIntrinsicWidth(), drawableR.getIntrinsicHeight());
		drawableR.setBounds(-drawableR.getIntrinsicWidth()/2, -drawableR.getIntrinsicHeight(), drawableR.getIntrinsicWidth()/2, 0); 
		itemizedOverlay = new WorldItemizedOverlay(drawableY, this);
		if (!getResources().getBoolean(R.bool.isTablet))
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); // portrait only for phone
		setPlaces();
		setBallons();
		//-----
		prefs = getSharedPreferences("mypref", MODE_PRIVATE);
		greeting = prefs.getBoolean("greeting", true);
		DisplayMetrics metrics = getResources().getDisplayMetrics();
		// Scale up if possible (based on GraphView)
		// Scale is computed for portrait only but also used for landscape
		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
			numPxH = metrics.heightPixels;
			numPxW = metrics.widthPixels;
		} else {
			numPxH = metrics.widthPixels;
			numPxW = metrics.heightPixels;
		}
		if (2*(366 + 35 + 30) + 30 < numPxW) {
			scale = numPxW/(366 + 35 + 30);
		}
	}
	// create the Activity's menu from a menu resource XML file
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.worldmap_menu, menu);
		return true;
	} 
	// called each time menu is pressed
	@Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem itemPlaces = menu.findItem(R.id.placesItem);
        MenuItem itemGraph = menu.findItem(R.id.graphItem);
        MenuItem itemSector = menu.findItem(R.id.sectorItem);
        MenuItem itemAdd = menu.findItem(R.id.addItem);
        MenuItem itemDelete = menu.findItem(R.id.deleteItem);
        MenuItem itemMap = menu.findItem(R.id.mapItem);
        MenuItem itemSat = menu.findItem(R.id.satItem);
        MenuItem itemHelp = menu.findItem(R.id.helpItem);
        MenuItem itemAbout = menu.findItem(R.id.aboutItem);

        itemPlaces.setVisible(true);
        itemGraph.setVisible(true);
        itemSector.setVisible(true);
        itemAdd.setVisible(true);
        itemDelete.setVisible(true);
        itemMap.setVisible(satellite);
        itemSat.setVisible(!satellite);
        itemHelp.setVisible(true);
        itemAbout.setVisible(true);
		
        return true;
	}
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
		DBAdapter db; 
		// Pick up two checked places
		int position1 = -1;
		int position2 = -1;
		for (int i=0; i < checked.size(); i++) {
			if (checked.get(i))
				if (position1 == -1)
					position1 = i;
				else if (position2 == -1)
					position2 = i;
				else  // both is set
					break;
		}
		
    	switch (item.getItemId()) {
    	case R.id.mapItem:
    	case R.id.satItem:
    		satellite = !satellite;
    		mapView.setSatellite(satellite);
    		return true;
    	case R.id.helpItem: // Help
    		startActivity(new Intent(this, HelpActivity.class));
    		return true;
    	case R.id.placesItem: // My Places
    		listPlaces();
    		return true;
    	case R.id.addItem: // Add location
    		startActivityForResult(new Intent(this, AddActivity.class), 99);
    		return true;
       	case R.id.deleteItem: // Delete selected locations. Max 50!
       		int numdel = 0;
       		for (int i=0; i < checked.size(); i++) {
       			if (checked.get(i)) 
       				numdel++;
       		}
       		if (numdel > 0) { // Dialog to get OK
       			AlertDialog.Builder builder = new AlertDialog.Builder(this);
       			builder.setTitle("Delete Places");
       			if (numdel == 1)
       				builder.setMessage("Delete " + numdel + " place?");
       			else
       				builder.setMessage("Delete " + numdel + " places?");
       			builder.setCancelable(true);
       			builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {		
       				@Override
       				public void onClick(DialogInterface dialog, int which) {
       					long rowid;
       					DBAdapter db = new DBAdapter(WorldMap.this);
       					db.open();
       					for (int i=0; i < checked.size(); i++) {
       		       			if (checked.get(i)) {
       		       				rowid = ids.get(i);
       		       				db.deleteLoc(rowid);
		        	    		db.deleteYTable("L" + rowid);
       		       			}
       					}
       					db.close();
       					setPlaces();
       					setBallons();
				}
			});
			builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.cancel();
				}
			});
			builder.show();
		}
		return true;
       	case R.id.graphItem: // Graph location: Up & down
    		int num = 0; // number of locs to graph (1 or 2)
    		if (position1 == -1 && position2 == -1)
    			CommonFun.toastNow("You must select a place", this);
    		else {
    			Intent i = new Intent(this, GraphActivity.class);
    			i.putExtra("type", 4);
    			if (position1 != -1 && position2 != -1 ) {
    				num += 2;
    				db = new DBAdapter(this);
    				String ytab1 = "L" + ids.get(position1);
    				String ytab2 = "L" + ids.get(position2);
    				i.putExtra("ytab1", ytab1);
    				i.putExtra("ytab2", ytab2);
    				db.open();
    				Cursor cur1 = db.getADay(ytab1, 366);
    				Cursor cur2 = db.getADay(ytab2, 366);
     				if (cur1.getCount() != cur2.getCount()) 
    					 num = 0; // Only one year is leap year
     				cur1.close();
     				cur2.close();
     				db.close();
        		} else { // only postion1 is set
    				num = 1;
    				i.putExtra("ytab1", "L" + ids.get(position1));
        		}
    				
    			if (num == 0) { // Only one year is leap year. Can't compare.
    				CommonFun.toastNow("Cannot compare years: Not the same number of days.", this);
    			} else {
    				i.putExtra("num", num);
    				startActivity(i);
    			}
    		}
    		return true;
    	case R.id.sectorItem: // Map location: Azimuth
    		if (position1 == -1 && position2 == -1)
    			CommonFun.toastNow("You must select a place", this);
    		else {
    			Intent i = new Intent(this, AzimuthMap.class);
    			i.putExtra("type", item.getItemId());
    			i.putExtra("ytab1", "L" + ids.get(position1));
    			startActivity(i);
    		}
    		return true;
       	case R.id.aboutItem: // Map location: Azimuth
    		about();
    		return true;
    	default:
    		return super.onOptionsItemSelected(item);
    	}
    }
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (requestCode == 99) { // add place
			if (resultCode == RESULT_OK) {
				setPlaces();
				setBallons();
			}
		}
	}
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
	private void listPlaces() {
		String [] strPlaces = new String[places.size()];
		final boolean[] bChecked = new boolean[places.size()];
		for (int i = 0; i < places.size(); i++) {
			strPlaces[i] = places.get(i);
			bChecked[i] = checked.get(i);
		}
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Select place(s)");
		builder.setMultiChoiceItems(strPlaces, bChecked, 
				new android.content.DialogInterface.OnMultiChoiceClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int item, boolean isChecked) {
				bChecked[item] = isChecked;
			}
		});
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// save the new checkings
				for (int i = 0; i < places.size(); i++) {
					checked.set(i, bChecked[i]);
				}
				setBallons();
				dialog.dismiss();
			}
		});
	    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		alertDialog = builder.create();
		alertDialog.show();
	}
	private void setPlaces() {
		String place;
		Double lat, lng;
		String tz;
		String tzId;
		String tzInfo;
		String mess;
		String dstOff = "+0:00";
		String dstSta = "";
		String dstEnd = "";
		ids.clear();
		places.clear();
		infos.clear();
		checked.clear();
		lats.clear();
		lngs.clear();
		DBAdapter db = new DBAdapter(WorldMap.this);
	    db.open();
	    Cursor c = db.getAllLocs();
	    if (c.moveToFirst())
	    {
	    	do {
	    		tz = tzId = "";
	    		ids.add(c.getLong(0));
	    		place = c.getString(1);
	    		places.add(place);
	    		checked.add(false);
	    		lat = c.getDouble(3);
	    		lats.add(lat);
	    		lng = c.getDouble(4);
	    		lngs.add(lng);
	    		tzInfo = c.getString(2);
	    		String tzFi[] = tzInfo.split("#");
	    		// 1) tz 2) tz id 3) DST offset 4) DST start 5) DST end
	    		tz = "";
	    		tzId = "";
	    		if (tzFi.length >= 2) {
	    			tz = tzFi[0];
	    			tzId = tzFi[1];
	    		}
	    		if (tzFi.length >= 3)
	    			dstOff = tzFi[2];
	    		if (tzFi.length >= 4) {
	    			dstSta = tzFi[3];
	    			dstEnd = tzFi[4];
	    		}
	    		mess = String.format(Locale.US, "(%1$3.6f,%2$4.6f)", lat, lng) + 
	    				"\n" + "TZ: " + tz + "\n" + "TZ id: " + tzId;
	    		mess += "\nDST Offset: " + dstOff;
	    		if (dstOff.length() > 0 && !dstOff.contentEquals("+0:00")) 
	    			mess = mess + "\nDST Start: " + dstSta + "\n" + "DST End: " + dstEnd;
	    		infos.add(mess);
	    	} while (c.moveToNext());
	    }
	    db.close();
	    c.close();
	}
	// remove all ballons and add them again with correct color
	public void setBallons() {
		itemizedOverlay.clear();
		mapOverlays = mapView.getOverlays();
		mapOverlays.clear();
		for (int i = 0; i < places.size(); i++) {
			itemizedOverlay.addOverlay(new OverlayItem(new GeoPoint((int)(lats.get(i)*1E6),(int)(lngs.get(i)*1E6)), 
    				places.get(i), infos.get(i)));
		}
		if (itemizedOverlay.size() > 0)
			mapOverlays.add(itemizedOverlay);
		for (int i = 0; i < itemizedOverlay.size(); i++) {
			if (checked.get(i))
				itemizedOverlay.getItem(i).setMarker(drawableR);
			else
				itemizedOverlay.getItem(i).setMarker(drawableY);			
		}
	    //Log.d("SolarOne", "setBallons: mapOverlays.size()=" + mapOverlays.size());
	    //Log.d("SolarOne", "setBallons: itemizedoverlay.size()=" + itemizedOverlay.size());
	    mapView.invalidate();
	}
	public void about() {
		AlertDialog.Builder inputDialog = new AlertDialog.Builder(this);
		inputDialog.setTitle("SolarOne v1.4");
		inputDialog.setCancelable(false);
	    inputDialog.setIcon(R.drawable.ic_launcher_solarone);
	    inputDialog.setMessage(Html.fromHtml("GubboIT 2014<br />" +
	    		"<a href=\"http://www.gubboit.se\">www.gubboit.se</a><br /><br />" +
	    	    "Mail to:" + "<a href=\"mailto:info@gubboit.se\">info@gubboit.se</a>"));
	    inputDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
	    inputDialog.setNeutralButton("More apps", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("market://search?q=pub:GubboIT"));
				startActivity(intent);
				dialog.dismiss();
			}
		});
	    alertDialog = inputDialog.create();
	    alertDialog.show();
	    // Need to be called after show(), in order to generate hyperlinks
	    ((TextView) alertDialog.findViewById(android.R.id.message)).setMovementMethod(LinkMovementMethod.getInstance());
}
}

