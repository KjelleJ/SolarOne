//-----------------------------------------------------------------------------
// HelpActivity.java
//
// 2012-2014 GubboIT
//
// 2014-01-31 Home button/icon added
// 2014-01-29 Zoom added
// 2013-11-11 Only portrait for phone
// 2012-02-22 First version
//-----------------------------------------------------------------------------
package se.gubboit.solarone;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.widget.ZoomButtonsController;

public class HelpActivity extends Activity {
	/** Called when the activity is first created. */	
	@SuppressLint("NewApi")
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.helpactivity);
	    WebView wv = (WebView) findViewById(R.id.webview);  
	    wv.getSettings().setBuiltInZoomControls(true);
		if (Build.VERSION.SDK_INT >= 14)
			getActionBar().setHomeButtonEnabled(true);
		if (Build.VERSION.SDK_INT >= 11)
			getActionBar().setDisplayHomeAsUpEnabled(true);
		if (Build.VERSION.SDK_INT >= 19) {
			wv.getSettings().setLayoutAlgorithm(LayoutAlgorithm.TEXT_AUTOSIZING);
		}
	    wv.loadUrl("file:///android_asset/readme.htm");
		if (!getResources().getBoolean(R.bool.isTablet))
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); // portrait only for phone
	}
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId()) {
    	case android.R.id.home:
    		Intent intent = new Intent(this, WorldMap.class);
    		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    		startActivity(intent);
    		break;
    	}
    	return super.onOptionsItemSelected(item);	
    } 
}