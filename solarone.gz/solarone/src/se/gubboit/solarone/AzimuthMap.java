//-----------------------------------------------------------------------------
// AzimuthMap.java
//
// 2012-2014 GubboIT
//
// 2014-01-31 Home button/icon added
// 2013-11-12 Only place in title
// 2013-11-12 Horizontal yearline for landscape
// 2013-11-11 Only portrait for phone
// 2013-11-11 Handle screen orientation
// 2013-11-08 + and - buttons added
// 2013-11-08 Animate button moved to menu
// 2013-11-04 Add background to buttons on map
// 2013-11-02 Scale graphics
// 2013-04-02 tz info added to info dialog
// 2012-02-25 No built in zoom control
// 2012-02-24 Accept only clicks within yearline
// 2012-02-22 First version
// 2013-01-24 Animation added
//-----------------------------------------------------------------------------
package se.gubboit.solarone;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.Overlay;
import com.google.android.maps.MapView;

public class AzimuthMap extends MapActivity {
	boolean satellite = false;
	boolean landscape = false;
	private int scale;
	MapView mapView;
	MapController mc;
	GeoPoint p;
	DBAdapter db = new DBAdapter(this);
	String ytab1;
	int t_year, p_month, p_day, a_month, a_day;
	int t_dayno; // day to show 0-366
	int ldayno; // last dayno in year 
	Calendar cur;
	int hup, mup, hdown, mdown, hlen, mlen;
	double elev, aziup, azidown;
	double latitude, longitude;
	String tz = "";
	String tzId = "";
	String dstOff = "";
	String dstStart = "";
	String dstEnd = "";
	String title = "";
	TextView txtTitle; 
	static final int DEFAULTDATESELECTOR_ID = 1;
	Timer timer;
	boolean animateNow = false;

	// Solar sector etc
	class MapOverlay extends com.google.android.maps.Overlay
	{
		@Override
		public boolean draw(Canvas canvas, MapView mapView, boolean shadow, long when) 
		{
			String [] monN = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
			super.draw(canvas, mapView, shadow);
			Point screenPts = new Point();
			mapView.getProjection().toPixels(p, screenPts);
			Paint paint = new Paint();
			String dz = "";
			Cursor c;
			db.open();
			c = db.getADay(ytab1, t_dayno);
			hup = c.getInt(3);
			mup = c.getInt(4);
			hdown = c.getInt(5);
			mdown = c.getInt(6);
			hlen = c.getInt(7);
			mlen = c.getInt(8);
			elev = c.getDouble(9);
			aziup = c.getDouble(10);
			azidown = c.getDouble(11);
			c.close();
			db.close();
			RectF oval = new RectF();
			int size = 200*scale;
			if (hlen == 24) {
				paint.setColor(Color.YELLOW);
				paint.setAlpha(100);
				paint.setStyle(Style.FILL);
				canvas.drawCircle(screenPts.x, screenPts.y, size, paint); // Midnight sun
			}
			else if (elev > 0.0) {
				oval.bottom = screenPts.y + size;
				oval.top = screenPts.y - size;
				oval.left = screenPts.x - size;
				oval.right = screenPts.x + size;
				double angsta;
				if (aziup <= 90.0)
					angsta = 270.0 + aziup;
				else
					angsta =  aziup - 90.0;
				paint.setStyle(Style.FILL);
				paint.setColor(Color.YELLOW);
				paint.setAlpha(100);
				// Note: drawArc is drawing clockwise!
				if (latitude >= 0.0)
					canvas.drawArc(oval, (float)angsta, (float)(azidown - aziup), true, paint);
				else
					canvas.drawArc(oval, (float)(azidown -90.0), (float)(360 - azidown + aziup), true, paint); // passing north
			}
			// Add circle + arrows to show how the sun seems to move
			paint.setStyle(Style.STROKE);
			paint.setStrokeWidth(5*scale);
			paint.setColor(Color.RED);
			paint.setTypeface(Typeface.MONOSPACE); 
			canvas.drawCircle(screenPts.x, screenPts.y, 50*scale, paint);
			int sign = -1; 
			if (latitude >= 0.0)
				sign = 1; // Arrows differ in north/south
			// Down arrow
			canvas.drawLine(screenPts.x + sign*50*scale, screenPts.y, 
				screenPts.x + sign*50*scale - 10*scale, screenPts.y - 10*scale, paint);
			canvas.drawLine(screenPts.x + sign*50*scale, screenPts.y, 
				screenPts.x + sign*50*scale + 10*scale, screenPts.y - 10*scale, paint);
			// Up arrow
			canvas.drawLine(screenPts.x - sign*50*scale, screenPts.y,
				screenPts.x - sign*50*scale - 10*scale, screenPts.y + 10*scale, paint);
			canvas.drawLine(screenPts.x - sign*50*scale, screenPts.y,
				screenPts.x - sign*50*scale + 10*scale, screenPts.y + 10*scale, paint);
			// Add date
			paint.setStyle(Style.FILL);
			paint.setTextSize(scale*50);
			paint.setStrokeWidth(2*scale);
			if (cur.get(Calendar.DAY_OF_MONTH) < 10)
				dz = "0";
			canvas.drawText(monN[cur.get(Calendar.MONTH)] + dz + cur.get(Calendar.DAY_OF_MONTH), screenPts.x - 75*scale, screenPts.y - 80*scale, paint);
			return true;
		}
	}
	// Yearline: horizontal if landscape otherwise vertical
	class MapOverlay2 extends com.google.android.maps.Overlay
	{
		private int height;
		private int touchy = 0;
		private int width = 50*scale;
		private int lmarg = 20*scale;
		private Bitmap cache;
		@Override
		public boolean draw(Canvas canvas, MapView mapView, boolean shadow, long when) 
		{
			float textsize = 30f*scale;
			String [] monax = { "J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"};
			int day, month;
			Paint paint = new Paint();
			paint.setTextSize(textsize);
			paint.setFakeBoldText(true);
			paint.setTypeface(Typeface.MONOSPACE); 
			paint.setAntiAlias(true);
			paint.setStyle(Style.FILL);
			paint.setColor(Color.RED);
			paint.setStrokeWidth(3*scale);
			super.draw(canvas, mapView, shadow);
			height = mapView.getHeight(); // tricky otherwise because of nav bar etc
			if (cache == null) { // Create and draw bitmap
				if (!landscape)
					cache = Bitmap.createBitmap(30*scale, 2*366*scale, Bitmap.Config.ARGB_8888);
				else
					cache = Bitmap.createBitmap(2*366*scale, 30*scale, Bitmap.Config.ARGB_8888);
				Canvas bmpCanvas = new Canvas(cache);
				Calendar plcal = Calendar.getInstance();
				for (month = 0; month <= 11; month++) {
					plcal.set(t_year, month, 1); // First day of month
					day = plcal.get(Calendar.DAY_OF_YEAR);
					if (!landscape) 
						bmpCanvas.drawLine(0, 2*day*scale, width, 2*day*scale, paint); // Draw month line
					else
						bmpCanvas.drawLine(2*day*scale, 0, 2*day*scale, width, paint); // Draw month line
					day += 20;
					if (!landscape)
						bmpCanvas.drawText(monax[month], 0, 2*day*scale, paint); // Draw month letter
					else
						bmpCanvas.drawText(monax[month], 2*(day - 10)*scale, 30*scale, paint); // Draw month letter
				}
				day = plcal.getMaximum(Calendar.DAY_OF_YEAR);
				//paint.setStrokeWidth(3*scale);
				if (!landscape)
					bmpCanvas.drawLine(0, 2*(day - 1)*scale, width, 2*(day - 1)*scale, paint); // Draw month line for last day of year
				else
					bmpCanvas.drawLine(2*(day - 1)*scale, 0, 2*(day - 1)*scale, width, paint); // Draw month line for last day of year
			}
			if (!landscape)
				canvas.drawBitmap(cache, lmarg, 0, paint); // Just use saved bitmap
			else

				canvas.drawBitmap(cache, 0, height - 30*scale - lmarg, paint); // Just use saved bitmap
			paint.setColor(Color.RED);
			//paint.setStrokeWidth(3*scale);
			// -1 to adjust for marker 3 pix
			if (!landscape)
				canvas.drawLine(lmarg, 2*t_dayno*scale, lmarg + width, 2*t_dayno*scale, paint); // Draw marker line
			else
				canvas.drawLine(2*t_dayno*scale, height - lmarg, 2*t_dayno*scale, height - width - lmarg, paint); // Draw marker line
			return true;
		}

		@Override
		public boolean onTouchEvent(MotionEvent event, MapView mapView)
		{
			int x, y;
			if (event.getAction() == 1 && !animateNow) {
				y = (int) event.getY(); // check within bitmap!!!!
				x = (int) event.getX();
				if (!landscape && (y >=2*scale && y <= 2*365*scale && x <= 50*scale)) {
					touchy = y;
					t_dayno = (touchy / 2)/scale;
					cur.set(Calendar.DAY_OF_YEAR, t_dayno);
					//p_month = cur.get(Calendar.MONTH);
		            //p_day = cur.get(Calendar.DAY_OF_MONTH);
					//txtTitle.setText(title + prdate(t_year, p_month + 1, p_day));
					mapView.invalidate();
				} else if (landscape && (x >=2*scale && x <= 2*365*scale && y <= height - lmarg &&
						y >= height - 30*scale - lmarg)) {
					touchy = x;
					t_dayno = (touchy / 2)/scale;
					cur.set(Calendar.DAY_OF_YEAR, t_dayno);
					//p_month = cur.get(Calendar.MONTH);
		            //p_day = cur.get(Calendar.DAY_OF_MONTH);
					//txtTitle.setText(title + prdate(t_year, p_month + 1, p_day));
					mapView.invalidate();
				}				
			}
			return false;
		}
	}

	@SuppressLint("NewApi")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		scale = WorldMap.scale;
		setContentView(R.layout.azimuthmap);
		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
			landscape = true;
		cur = Calendar.getInstance(); // Today
		ImageButton btnInfo = (ImageButton)findViewById(R.id.btnInfo);
		Button btnPlus = (Button)findViewById(R.id.btnPlus);
		Button btnMinus = (Button)findViewById(R.id.btnMinus);
		if (Build.VERSION.SDK_INT >= 14) { // Hard to see otherwise...
			btnInfo.setBackgroundColor(Color.RED);
			btnPlus.setBackgroundColor(Color.RED);
			btnMinus.setBackgroundColor(Color.RED);
			btnPlus.setTextColor(Color.WHITE);
			btnMinus.setTextColor(Color.WHITE);	
			getActionBar().setHomeButtonEnabled(true);
		}
		if (Build.VERSION.SDK_INT >= 11)
			getActionBar().setDisplayHomeAsUpEnabled(true);
		txtTitle = (TextView)findViewById(R.id.txtTitle);
		btnInfo.setOnClickListener(btnInfoListener);
		db.open();
		ytab1 = this.getIntent().getExtras().getString("ytab1");
		Cursor c = db.getLoc(Long.parseLong(ytab1.replace("L", "")));
		title = c.getString(1) + title; // Add place to title
		String tzFi[] = c.getString(2).split("#");
		tz = "";
		tzId = "";
		dstOff = "";
		dstStart = "";
		dstEnd = "";
		if (tzFi.length >= 2) {
			tz = tzFi[0];
			tzId = tzFi[1];
			dstOff = tzFi[2];
		}
		if (tzFi.length >= 4) {
			dstStart = tzFi[3];
			dstEnd = tzFi[4];
		}
		latitude = c.getDouble(3);
		longitude = c.getDouble(4);
		t_year = c.getInt(5);
		c.close();
		db.close();
		t_dayno = cur.get(Calendar.DAY_OF_YEAR);
		if (t_dayno == 365)
			t_dayno--; // Problem with leap year
		cur.set(Calendar.DAY_OF_YEAR, t_dayno); // set correct day and month
		cur.set(Calendar.YEAR, t_year); // set correct year
		//p_month = cur.get(Calendar.MONTH);
		//p_day = cur.get(Calendar.DAY_OF_MONTH);
		{ // get last dayno of year
			Calendar cur2 = Calendar.getInstance();
			cur2.set(t_year, 11, 31);
			ldayno = cur2.get(Calendar.DAY_OF_YEAR);
		}
		mapView = (MapView) findViewById(R.id.azimuthmap);
		mapView.setSatellite(satellite);
		//mapView.setStreetView(true); // BUG in Google MAP!!!!
		mc = mapView.getController();
		p = new GeoPoint((int)(latitude * 1E6), (int)(longitude * 1E6));
		mc.animateTo(p);
		mc.setZoom(Math.min(mapView.getMaxZoomLevel(), 18));
		mc.setCenter(p); // Needed?
		MapOverlay mapOverlay = new MapOverlay();
		MapOverlay2 mapOverlay2 = new MapOverlay2();
		List<Overlay> listOfOverlays = mapView.getOverlays();
		listOfOverlays.clear();
		listOfOverlays.add(mapOverlay);
		listOfOverlays.add(mapOverlay2);
		//txtTitle.setText(title + prdate(t_year, p_month + 1, p_day));
		txtTitle.setText(title);
		if (!getResources().getBoolean(R.bool.isTablet))
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); // portrait only for phone
		mapView.invalidate();
		
		btnMinus.setOnClickListener(new View.OnClickListener() {	
			@Override
			public void onClick(View v) {
				if (animateNow)
					return;
				t_dayno--;
				if (t_dayno < 1)
					t_dayno = ldayno;  // wrap-around
				cur.set(Calendar.DAY_OF_YEAR, t_dayno);
				//p_month = cur.get(Calendar.MONTH);
	            //p_day = cur.get(Calendar.DAY_OF_MONTH);
				//txtTitle.setText(title + prdate(t_year, p_month + 1, p_day));
				mapView.invalidate();
				}
			});
		
		btnPlus.setOnClickListener(new View.OnClickListener() {	
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (animateNow)
					return;
				t_dayno++;
				if (t_dayno > ldayno)
					t_dayno = 1;  // wrap-around
				cur.set(Calendar.DAY_OF_YEAR, t_dayno);
				//p_month = cur.get(Calendar.MONTH);
	            //p_day = cur.get(Calendar.DAY_OF_MONTH);
				//txtTitle.setText(title + prdate(t_year, p_month + 1, p_day));
				mapView.invalidate();
			}
		});
	}
	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putInt("latE6", p.getLatitudeE6());
		outState.putInt("lngE6", p.getLongitudeE6());
		outState.putBoolean("satellite", satellite);
		outState.putInt("t_dayno", t_dayno);
		super.onSaveInstanceState(outState);
	}
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		p = new GeoPoint(savedInstanceState.getInt("latE6"), savedInstanceState.getInt("lngE6"));
		satellite = savedInstanceState.getBoolean("satellite");
		t_dayno = savedInstanceState.getInt("t_dayno");
		mapView.setSatellite(satellite);
		cur.set(Calendar.DAY_OF_YEAR, t_dayno);
		//p_month = cur.get(Calendar.MONTH);
        //p_day = cur.get(Calendar.DAY_OF_MONTH);
		//txtTitle.setText(title + prdate(t_year, p_month + 1, p_day));
		mapView.invalidate();
	}

	private OnClickListener btnInfoListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			if (animateNow)
				return;
			AlertDialog.Builder builder = new AlertDialog.Builder(AzimuthMap.this);
			p_month = cur.get(Calendar.MONTH);
	        p_day = cur.get(Calendar.DAY_OF_MONTH);
			builder.setTitle(title + ": " + prdate(t_year, p_month + 1, p_day));
			builder.setPositiveButton("OK", null);
			String mess = "Up: " + formTime(hup, mup) + "\n" +
				"Down: " + formTime(hdown, mdown) + "\n" +
				"Length: " + formTime(hlen, mlen) + "\n" +
				"Max Elevation: " + Double.toString(elev) + " degrees\n" +
				"Azimuth Up: " + Double.toString(aziup) + " degrees\n" + 
				"Azimuth Down: " + Double.toString(azidown) + " degrees\n" +
				String.format(Locale.US, "(%1$3.6f,%2$4.6f)\n", latitude, longitude) +
				"TZ: " + tz + "\n" +
				"TZ id: " + tzId + "\n" +
				"DST Offset: " + dstOff;
			if (!dstOff.contentEquals("+0:00")) {
				mess += "\nDST Start: " + dstStart + "\n" +
						"DST End: " + dstEnd;
			}
			builder.setMessage(mess);
			AlertDialog infoDialog = builder.create();
			infoDialog.show();
		}
	};

	private void animateY() {
		timer = new Timer(); 
		a_month = 0;
        a_day = 5;
		timer.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				cur.set(t_year, a_month, a_day);
				t_dayno = cur.get(Calendar.DAY_OF_YEAR);
				p_month = a_month;
				p_day = a_day;
		        runOnUiThread(new Runnable() {
		                @Override
		                public void run() {
		            		//txtTitle.setText(title + prdate(t_year, p_month + 1, p_day));
		                	mapView.invalidate();
		                }
		        });
		        a_day += 10;
		        if (a_day > 25) {
		        	a_month++;
		        	a_day = 5;
		        }
		        if (a_month == 12) {
					timer.cancel();
					animateNow = false;
		        }
			}
		}, 0, 500);
	}

	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
	String prdate(int year, int month, int day)
	{
		String syear, smonth, sday;
		syear = Integer.toString(year);
		if (syear.length() == 1)
			syear = "0" + syear;
		smonth = Integer.toString(month);
		if (smonth.length() == 1)
			smonth = "0" + smonth;
		sday = Integer.toString(day);
		if (sday.length() == 1)
			sday = "0" + sday;
		return syear + "-" + smonth + "-" + sday;
	}
	private String formTime(int h, int m)
	{
		String str1, str2;
		str1 = Integer.toString(h);
		if (str1.length() == 1)
			str1 = "0" + str1;
		str2 = Integer.toString(m);
		if (str2.length() == 1)
			str2 = "0" + str2;
		return str1 + ":" + str2;	
	}
	// create the Activity's menu from a menu resource XML file
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.azimuthmap_menu, menu);
		return true;
	} 
	// called each time menu is pressed
	@Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem itemAnimate = menu.findItem(R.id.animateItem);
        MenuItem itemMap = menu.findItem(R.id.mapItem);
        MenuItem itemSatellite = menu.findItem(R.id.satelliteItem);      
    	itemAnimate.setVisible(true);
    	itemMap.setVisible(true);
    	itemSatellite.setVisible(true);
        return true;
	}

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId()) {
    	case R.id.mapItem: // Map
    		mapView.setSatellite(false);
    		satellite = false;
			return true;
    	case R.id.satelliteItem: // Satellite
    		mapView.setSatellite(true);
    		satellite = true;
			return true;
    	case R.id.animateItem: // Animate
			if (!animateNow) {
				animateNow = true;
				animateY();
			}
    		return true;
    	case android.R.id.home:
    		Intent intent = new Intent(this, WorldMap.class);
    		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    		startActivity(intent);
    		return true;
		default:
			return super.onOptionsItemSelected(item); 
    	}    	  	
    }
}
