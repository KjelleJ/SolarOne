//-----------------------------------------------------------------------------
// GraphView.java
//
// 2012-2013 GubboIT
//
// 2013-11-02 Scale the graph
// 2013-10-25 Adapt font to screen size (tablet etc)
// 2013-04-02 Alpha 120 -> 140
// 2013-01-24 Azimuth graph removed
// 2012-02-22 First version
//-----------------------------------------------------------------------------
package se.gubboit.solarone;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.os.AsyncTask;
import android.view.View;

public class GraphView extends View {
	private int scale;
	public Bitmap cache;
	private boolean drawOK;
	private String yt1; // Table name
	private String yt2; // Table name
	private int num; // Number of tables (1 or 2)
	private float [] dashed = {7f,7f};
	private int textax = 35; // Space for text under graph
	private int sptop = 10; // Space above graph
	private float textsize =20f;
	private static final String [] monax = { "J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"};
	Context ctx;
	public int type; // Type of graph: 3=Length of day, 4=Up & down, 5=Elevation
	int lday = 0;
	int markpos2; 
	
	public GraphView(Context context, int num, String yt1, String yt2, int type, int idl2) { // Constructor
		super(context);
		this.yt1 = yt1; // Table to be graphed
		this.yt2 = yt2; // Table to be graphed
		this.num = num;
		this.ctx = context;
		this.type = type;
		this.markpos2 = idl2;
		scale = WorldMap.scale;
		// NOTE: textax etc cannot be static -> they will be scaled for each instance!!!!????
		if (scale > 1) {
			dashed[0] *= scale;
			dashed[1] *= scale;
			textax *= scale;
			sptop *= scale;
			textsize *= scale;
		}
		setMinimumWidth(scale*366 + textax); // 366 (days in a year)
		setMinimumHeight(scale*15*24 + textax + sptop); // 360: Should be a multiple of 24 (hours in a day) 
	}
	private class BackgroundTask extends AsyncTask <Canvas, Void, Integer> {
		// NOTE: Void means not used!!!
		protected Integer doInBackground(Canvas... canvas) {
			drawCachedBitmap(canvas[0]);
			return 0;
		}
		protected void onPostExecute(Integer result) {
			drawOK = true;
			invalidate(); // Show the new bitmap
		}
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		setMeasuredDimension(getSuggestedMinimumWidth(),
			getSuggestedMinimumHeight());
	}
	@Override
	protected void onDraw(Canvas canvas) {
		// Problem: onDraw is called b4 bitmap is finished. Probably from Menu item....
		// drawOK solves this
		if (cache == null) { // Create and draw bitmap
			drawOK = false;
			cache = Bitmap.createBitmap(getMeasuredWidth(), getMeasuredHeight(),
					Bitmap.Config.ARGB_8888);
			new BackgroundTask().execute(new Canvas(cache)); // Draw graph bitmap in background
			return;
		}
		if (drawOK == false)
			return;
		Paint paint = new Paint();
		canvas.drawBitmap(cache, 0, 0, paint); // Just use saved bitmap
		paint.setColor(Color.RED);
		paint.setStrokeWidth(3*scale);
		// -1 to adjust for marker 3 pix
		canvas.drawLine(scale*(markpos2 - 1), sptop, scale*(markpos2 - 1), getMeasuredHeight() - textax, paint); // Draw marker line2
	}
	public void markPos2(int xpos) {
		if (markpos2 != xpos)
			this.invalidate();
		markpos2 = xpos;
	}

	void drawCachedBitmap(Canvas canvas) {
		int maxx, maxy, psx, pey;
		maxx = getWidth() - 1*scale - textax;
		maxy = getHeight() - 1*scale - textax;
		psx = 0; // Plot start
		pey = maxy; // Plot end
		int step, stepto, stepmaj, deltay;
	
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		paint.setTextSize(textsize);
		paint.setFakeBoldText(true);
		paint.setAntiAlias(true);
		paint.setStyle(Style.FILL);
		// Draw hour lines (0-24) or degree lines (0, 5, 10,...,90)
		paint.setStrokeWidth(scale*1);
		paint.setPathEffect(new DashPathEffect(dashed, 0));
		if (type != 5) { // draw hour lines
			step = 1;
			stepmaj = 2;
			stepto = 24;
			deltay = 15;
		} else { // draw degree lines
			step = 5;
			stepmaj = 10;
			stepto = 90;
			deltay = 4;
		}
		for (int i=0; i <=stepto; i += step)
			canvas.drawLine(0, pey - scale*deltay*i, maxx, pey - scale*deltay*i, paint);
		paint.setPathEffect(null); 
		for (int i=0; i <= stepto; i += stepmaj) {
			canvas.drawLine(0, pey - scale*deltay*i, maxx, pey - scale*deltay*i, paint);
			canvas.drawText(Integer.toString(i), maxx + scale*5, pey - scale*deltay*i + (int)textsize/2 , paint);
		}
		
		DBAdapter db = new DBAdapter(ctx);
		db.open();
		lday = plotit(db, yt1, Color.RED, canvas, paint, psx, pey);
		if (num == 2)
			plotit(db, yt2, Color.YELLOW, canvas, paint, psx, pey);
		db.close();
	}
	
	int plotit(DBAdapter db, String yt, int color, Canvas canvas, Paint paint,
			 int psx, int pey) {
		int i = psx;
		int lday = 0;
		int month, day, hup, mup, hlen, mlen;
		double elev;
		Cursor c = db.getAllDays(yt);

		if (c.moveToFirst())
		{
			do {
				lday++;
				month = c.getInt(1);
				day = c.getInt(2);
				hup = c.getInt(3);
				mup = c.getInt(4);
				hlen = c.getInt(7);
				mlen = c.getInt(8);
				elev = c.getDouble(9);
							
				if (day == 1) { // Draw month line
					if ((month-1)%3!=0)
						paint.setPathEffect(new DashPathEffect(dashed, 0)); 
					paint.setColor(Color.BLACK);
					canvas.drawLine(scale*i, sptop, scale*i, pey, paint);
					paint.setPathEffect(null); 
				}
				if (day == 12) { // Draw letter for month
					paint.setColor(Color.BLACK);
					paint.setAlpha(255);
					canvas.drawText(monax[month-1], scale*i, pey + textax/2, paint);
				}
				paint.setColor(color);
				paint.setAlpha(140);    // Draw semi-transparent
				
				if (type == 3) // Length of day
					canvas.drawLine(scale*i, pey, scale*i, pey - 
		   					scale*(hlen*60 + mlen)*15/60, paint);
				if (type==4) // Up & down
					canvas.drawLine(scale*i, pey - scale*(60*hup + mup)*15/60, scale*i, 
							pey - scale*((60*hup + mup) + 60*hlen + mlen)*15/60, paint);
				if (type==5) // Elevation
					canvas.drawLine(scale*i, pey, scale*i, pey - (int)(scale*4*elev) , paint);
				i++;
			} while (c.moveToNext());
		}
		c.close();
		return lday;
	}
}


