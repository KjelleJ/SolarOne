// CommonFun.java - contains common functions
package se.gubboit.solarone;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

class CommonFun
{

    public static void toastNow(String message, Context context)
    {
    	Toast tText = Toast.makeText(context, message, Toast.LENGTH_LONG);
        tText.setGravity(Gravity.CENTER, 
          		tText.getXOffset() / 2, tText.getYOffset() / 2);     
        tText.show();
    }
}
