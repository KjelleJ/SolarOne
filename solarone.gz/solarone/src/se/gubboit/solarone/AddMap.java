//-----------------------------------------------------------------------------
// AddMap.java
//
// 2012-2014 GubboIT
//
// 2013-11-12 Map is default
// 2013-11-11 Only portrait for phone
// 2013-11-10 Handle screen orientation
// 2013-11-04 Add background to button on map
// 2012-04-13 Removed Mark button (can do without)
// 2012-02-25 No built in zoom control
// 2012-02-24 Some nw access in background to fix NetworkOnMainThreadException (Honeycomb)
// 2012-02-22 First version
//-----------------------------------------------------------------------------

package se.gubboit.solarone;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.Overlay;
import com.google.android.maps.MapView;

public class AddMap extends MapActivity {
	boolean satellite = false;
	private int scale;
	MapView mapView;
	MapController mc;
	GeoPoint p;
	String place;
	static double latitude, longitude;
	
	class MapOverlay extends com.google.android.maps.Overlay
	{
		@Override
		public boolean draw(Canvas canvas, MapView mapView, boolean shadow, long when) 
		{			
			//if (p != null && setPlace) {
			if (p != null) {
				super.draw(canvas, mapView, shadow);
				Point screenPts = new Point();
				mapView.getProjection().toPixels(p, screenPts);
				Paint paint = new Paint();
				paint.setStyle(Style.STROKE);
				paint.setStrokeWidth(5*scale);
				paint.setColor(Color.RED);
				paint.setAlpha(100);
				canvas.drawCircle(screenPts.x, screenPts.y, 15*scale, paint);
			}
			return true;
		}
		@Override
		public boolean onTouchEvent(MotionEvent event, MapView mapView)
		{
			if (event.getAction() == 1) {
				p = mapView.getProjection().fromPixels(
						(int) event.getX(),	(int) event.getY());
				latitude = p.getLatitudeE6()/1E6;
				longitude = p.getLongitudeE6()/1E6;
				mapView.invalidate();
			}
			return false;
		}
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		scale = WorldMap.scale;
		setContentView(R.layout.addmap);
		Button btnOK = (Button)findViewById(R.id.btnOK);
		if (Build.VERSION.SDK_INT >= 11) { // Hard to see otherwise...
			btnOK.setBackgroundColor(Color.RED);
			btnOK.setTextColor(Color.WHITE);
		}
		btnOK.setOnClickListener(btnOKListener);
		place = this.getIntent().getExtras().getString("place");	
		mapView = (MapView) findViewById(R.id.addmap);
		mapView.setSatellite(satellite);
		if (!getResources().getBoolean(R.bool.isTablet))
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); // portrait only for phone
		//mapView.setStreetView(true); // BUG in Google MAP API: Satellite and Street is no good!!!
		mc = mapView.getController();
		/* getFromLocationName is NOT WORKING ON EMULATOR!!! and Geocoder.isPresent only from API level9... */
		Geocoder geoCoder = new Geocoder(getBaseContext(), Locale.getDefault());
		try {
			// Not working on emulator => IOException Service not available!!!
			// KSS: Only pick up first proposal
			final List<Address> addresses = geoCoder.getFromLocationName(place, 1);
			if (addresses.size() > 0) {
				latitude = addresses.get(0).getLatitude();
				longitude = addresses.get(0).getLongitude();
				posMap();
			}
		} catch (IOException e) {
			// Assume running on AVD and "Service not available" problem...
			new BackgroundTask().execute(place);
		}
	}
	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putInt("latE6", p.getLatitudeE6());
		outState.putInt("lngE6", p.getLongitudeE6());
		outState.putBoolean("satellite", satellite);
		super.onSaveInstanceState(outState);
	}
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		p = new GeoPoint(savedInstanceState.getInt("latE6"), savedInstanceState.getInt("lngE6"));
		satellite = savedInstanceState.getBoolean("satellite");
		mapView.setSatellite(satellite);
	}
	
	private void posMap() {
		p = new GeoPoint(
				(int) (latitude * 1E6),
				(int) (longitude * 1E6));	
		if (p != null) { 
			mc.animateTo(p);
			mc.setZoom(Math.min(mapView.getMaxZoomLevel(), 18));
			mc.setCenter(p); // Needed?
		} else {
			mc.setZoom(4);
			// Set a default value for lat & long
			p = new GeoPoint((int)(60*1E6), (int)(20*1E6));
			mc.animateTo(p);
		}
		MapOverlay mapOverlay = new MapOverlay();
		List<Overlay> listOfOverlays = mapView.getOverlays();
		listOfOverlays.clear();
		listOfOverlays.add(mapOverlay); 
		mapView.invalidate();
	}

	private class BackgroundTask extends AsyncTask <String, Void, JSONObject> {
		protected JSONObject doInBackground(String... string) {
			return getLocationInfo(string[0]);
		}
		protected void onPostExecute(JSONObject jsonObj) {
			getLatLong(jsonObj);
			posMap();
		}
	}
	private OnClickListener btnOKListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			Intent data = new Intent();
			data.setData(Uri.parse(Double.toString(latitude) + "," + Double.toString(longitude)));
			setResult(RESULT_OK, data);
			finish();		
		}
	};

	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
	// Imported from http://stackoverflow.com/questions/3574644/how-can-i-find-the-latitude-and-longitude-from-address/3574792#3574792
	// Remove this after test????
	public static JSONObject getLocationInfo(String address) { 
        StringBuilder stringBuilder = new StringBuilder(); 
        try { 
 
        address = address.replaceAll(" ","%20");     
 
        HttpPost httppost = new HttpPost("http://maps.google.com/maps/api/geocode/json?address=" + address + "&sensor=false"); 
        HttpClient client = new DefaultHttpClient(); 
        HttpResponse response; 
        stringBuilder = new StringBuilder(); 
 
 
            response = client.execute(httppost); 
            HttpEntity entity = response.getEntity(); 
            InputStream stream = entity.getContent(); 
            int b; 
            while ((b = stream.read()) != -1) { 
                stringBuilder.append((char) b); 
            } 
        } catch (ClientProtocolException e) { 
        } catch (IOException e) { 
        } 
 
        JSONObject jsonObject = new JSONObject(); 
        try { 
            jsonObject = new JSONObject(stringBuilder.toString()); 
        } catch (JSONException e) { 
            // TODO Auto-generated catch block 
            e.printStackTrace(); 
        } 
 
        return jsonObject; 
    } 
	public static boolean getLatLong(JSONObject jsonObject) { 
		 
        try { 
 
            longitude = ((JSONArray)jsonObject.get("results")).getJSONObject(0) 
                .getJSONObject("geometry").getJSONObject("location") 
                .getDouble("lng"); 
 
            latitude = ((JSONArray)jsonObject.get("results")).getJSONObject(0) 
                .getJSONObject("geometry").getJSONObject("location") 
                .getDouble("lat"); 
 
        } catch (JSONException e) { 
            return false; 
 
        } 
        return true; 
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	super.onCreateOptionsMenu(menu);
    	menu.add(0, 1, 1, "Map");
    	menu.add(0, 2, 2, "Satellite"); 
    	return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId()) {
    	case 1: // Map
    		mapView.setSatellite(false);
    		satellite = false;
			return true;
    	case 2: // Satellite
    		mapView.setSatellite(true);
    		satellite = true;
			return true;
		default:
			return super.onOptionsItemSelected(item);	
    	}  	   	
    }
}
