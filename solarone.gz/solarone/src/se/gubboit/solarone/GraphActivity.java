//-----------------------------------------------------------------------------
// GraphActivity.java
//
// 2012-2014 GubboIT
//
// 2014-01-31 Action bar is used
// 2013-11-11 Only portrait for phone
// 2013-11-10 Handle screen orientation
// 2013-11-04 Title/Action bar added
// 2013-11-02 Yearline scaled
// 2013-04-02 Options order changed
// 2013-03-31 Info button for tz and DST info
// 2013-01-24 Azimuth graph removed
// 2012-02-22 First version
//-----------------------------------------------------------------------------
package se.gubboit.solarone;

import java.util.Calendar;
import java.util.Locale;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GraphActivity extends Activity {
	
	int idl2; // Current x-pos for marker and up/down info

	DBAdapter db = new DBAdapter(this);
	float sp;
	TextView txtDay12, txtDay22, txtHdr;
	ImageButton btnInfo1, btnInfo2;
	String ytab1, ytab2; // Table name of daily values
	int num;
	int type;
	GraphView graph;
	YearLineView yearLine;
	String stTitle;
	// 1) tz 2) tz id 3) DST offset 4) DST start 5) DST end
	String place[] = new String [2];
	String latlng[] = new String [2];
	String year[] = new String [2];
	String tz[] = new String [2];
	String tzId[] = new String [2];
	String dstOff[] = new String [2];
	String dstStart[] = new String [2];
	String dstEnd[] = new String [2];
	final int TYPE_LENGTH = 3;
	final int TYPE_RISE = 4;
	final int TYPE_ELEVATION = 5;

	@SuppressLint("NewApi")
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.graphactivity);
		if (Build.VERSION.SDK_INT >= 11 && 
				getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) // avoid ellipses...
			stTitle = "";
		else
			stTitle = "SolarOne - ";
		
		// Get number (1 or 2) and name of db tables from main activity
		num = this.getIntent().getExtras().getInt("num");
		ytab1 = this.getIntent().getExtras().getString("ytab1");
		if (num == 2)
			ytab2 = this.getIntent().getExtras().getString("ytab2");
	
		Button btnPlus = (Button) findViewById(R.id.btnPlus);
		Button btnMinus = (Button) findViewById(R.id.btnMinus); 
		btnInfo1 = (ImageButton)findViewById(R.id.btnInfo1);
		btnInfo1.setOnClickListener(btnInfoListener);
		btnInfo2 = (ImageButton)findViewById(R.id.btnInfo2);
		btnInfo2.setOnClickListener(btnInfoListener);
		if (Build.VERSION.SDK_INT >= 14)
			getActionBar().setHomeButtonEnabled(true);
		if (Build.VERSION.SDK_INT >= 11)
			getActionBar().setDisplayHomeAsUpEnabled(true);

		btnMinus.setOnClickListener(new View.OnClickListener() {	
			@Override
			public void onClick(View v) {
				db.open();
				idl2--;
				if (idl2 < 1)
					idl2 = graph.lday; // wrap-around
				Cursor cur = db.getADay(ytab1, (long)idl2);
				txtDay12.setText(setLine(cur));
				cur.close();
				if (num == 2) {
					cur = db.getADay(ytab2, (long)idl2);
					txtDay22.setText(setLine(cur));
					cur.close();
				}
				db.close();
				graph.markPos2(idl2);
				}
			});
		
		btnPlus.setOnClickListener(new View.OnClickListener() {	
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			db.open();
			idl2++;
			if (idl2 > graph.lday)
				idl2 = 1; // wrap-around
			Cursor cur = db.getADay(ytab1, (long)idl2);
			txtDay12.setText(setLine(cur));
			cur.close();
			if (num == 2) {			
				cur = db.getADay(ytab2, (long)idl2);
				txtDay22.setText(setLine(cur));
				cur.close();
			}	
			db.close();
			graph.markPos2(idl2);
			}
		});
		
		// Init text fields
		txtHdr = (TextView) findViewById(R.id.txtHdr);
		TextView txtName1 = (TextView) findViewById(R.id.txtName1);
		txtName1.setTextColor(Color.RED);
		TextView txtName2 = (TextView) findViewById(R.id.txtName2);
		txtName2.setTextColor(Color.YELLOW);
		txtDay12 = (TextView) findViewById(R.id.txtDay12);
		txtDay12.setTextColor(Color.RED);
		txtDay22 = (TextView) findViewById(R.id.txtDay22);
		txtDay22.setTextColor(Color.YELLOW);
		float px = 20*WorldMap.scale; // textsize in GraphView
		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
			txtHdr.setTextColor(Color.WHITE);
		txtHdr.setTextSize(0, px);
		txtName1.setTextSize(0, px);
		txtName2.setTextSize(0, px);
		txtDay12.setTextSize(0, px);
		txtDay22.setTextSize(0, px);
		btnPlus.setTextSize(0, px);
		btnMinus.setTextSize(0, px);
		db.open();
		setTzEtc(0, ytab1, txtName1);
		if (num == 2) {
			btnInfo2.setVisibility(ImageButton.VISIBLE);
			setTzEtc(1, ytab2, txtName2);
		}
		db.close();
		Calendar cur = Calendar.getInstance();
		int curday = cur.get(Calendar.DAY_OF_YEAR); 

		// Create graph
		type = this.getIntent().getExtras().getInt("type");
		if (type == TYPE_RISE) {
			this.setTitle(stTitle + "Rise & Set (Time)");
		}
		setUpDown(curday);
		
		graph = new GraphView(this, num, ytab1, ytab2, type, idl2);
		yearLine = new YearLineView(this, 2012);  // FIXA!!!!
		((LinearLayout) findViewById(R.id.yearline)).addView(yearLine, 0);
		((LinearLayout) findViewById(R.id.graph)).addView(graph, 0);
		if (!getResources().getBoolean(R.bool.isTablet))
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); // portrait only for phone
     
        yearLine.setOnTouchListener(
        		new View.OnTouchListener() {
        			@Override public boolean onTouch(View v, MotionEvent evt) {
        				if (evt.getAction() == MotionEvent.ACTION_UP) {
        					int xpos = (int)evt.getY();
        					xpos = (xpos/2)/WorldMap.scale;
        					if (xpos >= 1 && xpos <= 365) {// Prevent clicks outside	
        						setUpDown(xpos);
       						graph.markPos2(xpos);
        					}
        				}
        				return true;
        			}
        		});
	}
	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putInt("type", type);
		outState.putInt("idl2", idl2);
		super.onSaveInstanceState(outState);
	}
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		type = savedInstanceState.getInt("type");
		idl2 = savedInstanceState.getInt("idl2");
    	graph.type = type;
    	graph.cache = null;
    	graph.invalidate(); // had to add if action bar...
    	setUpDown(idl2);
    	graph.markPos2(idl2);
    	switch (type) {
    		case TYPE_LENGTH: // Graph location: Length of day
    		this.setTitle(stTitle + "Length of Day (Hours)");
			txtHdr.setText("      Rise  Set   Length");
			return;
    		case TYPE_RISE: // Graph location: Up & down
    		this.setTitle(stTitle + "Rise & Set (Time)");
			txtHdr.setText("      Rise  Set   Length");
			return;
    		case TYPE_ELEVATION: // Graph location: Elevation
    		this.setTitle(stTitle + "Max Elevation (Degrees)");
			txtHdr.setText("      Rise  Set   Elevation");
    	}
	}
	void setTzEtc(int ix, String ytab, TextView txt) {
		Cursor c = db.getLoc(Long.parseLong(ytab.replace("L", "")));
		place[ix] = c.getString(1);
		year[ix] = c.getInt(5) + "";
		latlng[ix] = String.format(Locale.US, "(%1$3.6f,%2$4.6f)", c.getDouble(3), c.getDouble(4));
		//latlng[ix] = "(" + c.getDouble(3) + "," + c.getDouble(4) + ")";
		txt.setText(place[ix] + " " + latlng[ix]);
		String tzInfo = c.getString(2);
		String tzFi[] = tzInfo.split("#");
		// 1) tz 2) tz id 3) DST offset 4) DST start 5) DST end
		tz[ix] = "";
		tzId[ix] = "";
		dstOff[ix] = "";
		dstStart[ix] = "";
		dstEnd[ix] = "";
		if (tzFi.length >= 2) {
			tz[ix] = tzFi[0];
			tzId[ix] = tzFi[1];
			dstOff[ix] = tzFi[2];
		}
		if (tzFi.length >= 4) {
			dstStart[ix] = tzFi[3];
			dstEnd[ix] = tzFi[4];
		}
		c.close();
	}
	
	String setLine(Cursor c) {
		String month, day, hup, mup, hdown, mdown, hlen, mlen;
		String [] monN = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
		double elev;
		
		if (c == null)
			return ""; // Will happen if not valid date
		month = monN[c.getInt(1) - 1];
		day = Integer.toString(c.getInt(2));
		if (day.length() == 1)
			day = "0" + day; 
		hup = Integer.toString(c.getInt(3));
		if (hup.length() == 1)
			hup = "0" + hup;
		mup = Integer.toString(c.getInt(4));
		if (mup.length() == 1)
			mup = "0" + mup;
		hdown = Integer.toString(c.getInt(5));
		if (hdown.length() == 1)
			hdown = "0" + hdown;
		mdown = Integer.toString(c.getInt(6));
		if (mdown.length() == 1)
			mdown = "0" + mdown;
		if (type != TYPE_ELEVATION) {
			hlen = Integer.toString(c.getInt(7));
			if (hlen.length() == 1)
				hlen = "0" + hlen;	
			mlen = Integer.toString(c.getInt(8));
			if (mlen.length() == 1)
				mlen = "0" + mlen;		
			return month + day + " " + hup + ":" + mup + " " +
			hdown + ":" + mdown + " " + hlen + ":" + mlen;
		} else { // type=5 (elevation)
			elev = c.getDouble(9);
			return month + day + " " + hup + ":" + mup + " " +
			hdown + ":" + mdown + " " + elev;
		}
	}
	void setUpDown(int dayno) { 
		Cursor c;
		db.open();
		idl2 = dayno;
		c = db.getADay(ytab1, (long)idl2);
		if (c == null)  // wrap-around
			idl2 = 1;
		else
			c.close();
		c = db.getADay(ytab1, (long)idl2);
		txtDay12.setText(setLine(c));
		c.close();
		if (num == 2) {
			c = db.getADay(ytab2, (long)idl2);
			txtDay22.setText(setLine(c));
			c.close();
		}
		db.close();
	}
	// create the Activity's menu from a menu resource XML file
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.graphactivity_menu, menu);
		return true;
	} 
	// called each time menu is pressed
	@Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem itemRise = menu.findItem(R.id.riseItem);
        MenuItem itemLength = menu.findItem(R.id.lengthItem);
        MenuItem itemElevation = menu.findItem(R.id.elevationItem);      
    	itemRise.setVisible(true);
    	itemLength.setVisible(true);
    	itemElevation.setVisible(true);
        return true;
	}
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId()) {
    	case R.id.lengthItem: // Graph location: Length of day
    		this.setTitle(stTitle + "Length of Day (Hours)");
			txtHdr.setText("      Rise  Set   Length");
			type = TYPE_LENGTH;
			break;
    	case R.id.riseItem: // Graph location: Up & down
    		this.setTitle(stTitle + "Rise & Set (Time)");
			txtHdr.setText("      Rise  Set   Length");
			type = TYPE_RISE;
			break;
    	case R.id.elevationItem: // Graph location: Elevation
    		this.setTitle(stTitle + "Max Elevation (Degrees)");
			txtHdr.setText("      Rise  Set   Elevation");
			type = TYPE_ELEVATION;
			break;	
    	case android.R.id.home:
    		Intent intent = new Intent(this, WorldMap.class);
    		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    		startActivity(intent);
    		break;
    	}
    	graph.type = type;
    	graph.cache = null;
    	graph.invalidate(); // had to add if action bar...
    	setUpDown(idl2); 
    	return super.onOptionsItemSelected(item);	
    } 
	private OnClickListener btnInfoListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			int ix = 0;
			String message;
			AlertDialog.Builder builder = new AlertDialog.Builder(GraphActivity.this);
			builder.setPositiveButton("OK", null);
			if (v.getId() == R.id.btnInfo2)
				ix = 1;
			builder.setTitle(place[ix] + " " + year[ix]);
			message = latlng[ix]+ "\n" +
				"TZ: " + tz[ix] + "\n" +
				"TZ id: " +  tzId[ix] + "\n" +
				"DST Offset: " + dstOff[ix];
			if (dstOff[ix].length() > 0 && !dstOff[ix].contentEquals("+0:00")) {
				message = message + 		
					"\nDST Start: " + dstStart[ix] + "\n" +
					"DST End: " + dstEnd[ix];
			}
			builder.setMessage(message);
			AlertDialog infoDialog = builder.create();
			infoDialog.show();
		}
	};
}