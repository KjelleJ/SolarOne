/** Automatically generated file. DO NOT MODIFY */
package se.gubboit.solarone;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}